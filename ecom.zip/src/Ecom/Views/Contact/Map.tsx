import React from 'react'

function Map() {
  return (
    <div className='container'>
      <div className='row'>
        <div className='col-lg-12 py-4'>
          
           <iframe width="100%" height="500" frameBorder="0" scrolling="no" marginHeight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=500&amp;hl=en&amp;q=92/77,pasumponnagar,palanganatham,madurai-3.+(Google%20map)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"><a href="https://www.maps.ie/population/">Population mapping</a></iframe>
        </div>
      </div>
    </div>
  )       
}

export default Map
