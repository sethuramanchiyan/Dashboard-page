import Mendress1 from '../../Assets/Images/Mendress1.jpg'
import Mendress2 from '../../Assets/Images/Mendress2.jpg'
import Mendress3 from '../../Assets/Images/Mendress3.jpg'
import womendress1 from '../../Assets/Images/womendress1.jpg'
import womendress2 from '../../Assets/Images/womendress2.jpg'
import womendress3 from '../../Assets/Images/womendress3.jpg'

const  Data={
productItems:[
    {
        id:1,
        price:'300rs',
        Name:'T-Shirt Name 10',
        count:1,
        img:{Mendress1}
    },
    {
        id:2,
        price:'350rs',
        Name:'T-Shirt Name 20',
        count:1,
        img:{Mendress2}
    },
    {
        id:3,
        price:'450rs',
        Name:'T-Shirt Name 40',
        count:1,
        img:{Mendress3}
    },
    {
        id:4,
        price:'450rs',
        Name:'T-Shirt Name 50',
        count:1,
        img:{womendress1}
    },
    {
        id:5,
        price:'400rs',
        Name:'T-Shirt Name 60',
        count:1,
        img:{womendress2}
    },
    {
        id:6,
        price:'550rs',
        Name:'T-Shirt Name 70',
        count:1,
        img:{womendress3}
    }
] 
}
    
 

